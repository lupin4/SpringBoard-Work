"""Flask app for Cupcakes"""
