"""Models for Cupcake app."""
